run dammen2.exe
it opens a command window

for moving pieces (called stukken or single stuk) in this game
if asks you for location of the piece you want to move
and the location of the place you want it to move too

the location is asked in two parts, the horizontal index or in which colum
and the lateral index, or which row

white pieces look like: O
white upgraded pieces look like: @

black pieces look like: #
black upgraded pieces look like: %

for further questions please ask me at: tiesnoordhuis@gmail.com