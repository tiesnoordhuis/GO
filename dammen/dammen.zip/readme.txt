visual display of board, move around using WASD

written by ties noordhuis

test for visual